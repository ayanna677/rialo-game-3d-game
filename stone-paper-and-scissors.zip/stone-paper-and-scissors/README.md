# Stone, Paper and Scissors

A Pen created on CodePen.

Original URL: [https://codepen.io/codegrind6/pen/mdPPeQg](https://codepen.io/codegrind6/pen/mdPPeQg).

